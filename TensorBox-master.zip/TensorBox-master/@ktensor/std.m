function s = std(Y)
% Standard devitation of all entries of k-tensor Y
%
% Phan Anh-Huy
s = sqrt(var(Y));